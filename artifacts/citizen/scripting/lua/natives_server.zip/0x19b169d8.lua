--- GET_VEHICLE_EXTRA_COLOURS
function Global.GetVehicleExtraColours(vehicle)
	return _in(0x80e4659b, vehicle, _i, _i)
end
