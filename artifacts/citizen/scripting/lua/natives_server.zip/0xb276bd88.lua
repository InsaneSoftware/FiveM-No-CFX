--- IS_VEHICLE_ENGINE_STARTING
function Global.IsVehicleEngineStarting(vehicle)
	return _in(0xbb340d04, vehicle, _r)
end
