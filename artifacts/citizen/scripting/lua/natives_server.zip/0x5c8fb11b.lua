--- HAS_VEHICLE_BEEN_OWNED_BY_PLAYER
function Global.HasVehicleBeenOwnedByPlayer(vehicle)
	return _in(0xe4e83a5b, vehicle, _r)
end
